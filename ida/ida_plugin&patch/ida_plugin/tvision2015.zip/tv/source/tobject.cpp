/*------------------------------------------------------------*/
/* filename -       tobject.cpp                               */
/*                                                            */
/* function(s)                                                */
/*                  TObject member functions                  */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TObject
#include <tv.h>

TObject::~TObject()
{
}

void TObject::shutDown()
{
}
