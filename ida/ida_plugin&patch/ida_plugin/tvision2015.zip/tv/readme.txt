How to compile TVision
----------------------

You will need IDA SDK to compile this version of TVision. Ensure that SDK is
installed and you can compile sample plugins from it.

  - unpack the TVsision archive into the directory with the SDK
  - cd tv/source
  - make


