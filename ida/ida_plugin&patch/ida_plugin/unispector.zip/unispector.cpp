// Unispector - display contents of unicode strings
// Copyright 2005 Ilfak Guilfanov <ig@hexblog.com>
// This is a freeware program but you you can not modify
// or delete the copyright message.

#include <windows.h>

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <kernwin.hpp>
#include <bytes.hpp>

static HWND ida_window; // main IDA window
static HWND hwnd;       // our window
static HWND th;         // edit control with the text

static ea_t displayed_ea = BADADDR;  // ea displayed in our window
static bool must_refresh = false;    // window requires refreshing

static wchar_t *text = NULL;         // current unicode string to display

static HINSTANCE hInstance = NULL;   // application instance
                                     // we do not know it, so will use NULL

//---------------------------------------------------------------------------
// Window Procedure for our Unicode Inspector window
LRESULT CALLBACK WndProc(HWND h, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
  RECT r;
  switch ( iMsg )
  {
    case WM_SIZE:
      GetClientRect(hwnd, &r);
      SetWindowPos(th, HWND_TOP, 0, 0, r.right, r.bottom,
       SWP_NOOWNERZORDER|SWP_DEFERERASE|SWP_NOMOVE|SWP_NOREDRAW|SWP_NOACTIVATE);
      break;
    case WM_ERASEBKGND:
      return 1;
    case WM_DESTROY:
      hwnd = NULL;
      break;
  }
  return DefWindowProc(h, iMsg, wParam, lParam);
}

//---------------------------------------------------------------------------
// Create Unicode Inspector window
static void create_window(void)
{
  static char classname[] = "Unispector";
  MSG         msg;
  WNDCLASSEX  wndclass;

  /*  Fill in WNDCLASSEX struct members  */

  wndclass.cbSize         = sizeof(wndclass);
  wndclass.style          = CS_HREDRAW | CS_VREDRAW;
  wndclass.lpfnWndProc    = WndProc;
  wndclass.cbClsExtra     = 0;
  wndclass.cbWndExtra     = 0;
  wndclass.hInstance      = hInstance;
  wndclass.hIcon          = LoadIcon(NULL, IDI_APPLICATION);
  wndclass.hIconSm        = LoadIcon(NULL, IDI_APPLICATION);
  wndclass.hCursor        = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground  = (HBRUSH) GetStockObject(WHITE_BRUSH);
  wndclass.lpszClassName  = classname;
  wndclass.lpszMenuName   = NULL;


  /*  Register a new window class with Windows  */

  RegisterClassEx(&wndclass);


  /*  Create a window based at the bottom of IDA window */

  RECT r;
  GetWindowRect(ida_window, &r);
  r.top = r.bottom - 80;

  hwnd = CreateWindow(classname, "Current unicode string",
                      WS_OVERLAPPEDWINDOW,
                      r.left, r.top,
                      r.right - r.left,
                      r.bottom - r.top,
                      ida_window, NULL, hInstance, NULL);

  GetClientRect(hwnd, &r);
  th = CreateWindowW(L"EDIT", NULL,
			WS_CHILD|WS_VISIBLE|ES_MULTILINE|ES_LEFT,
			0, 0,
			r.right, r.bottom,
			hwnd, NULL, NULL, NULL);

  // Show our window, do not activate it
  ShowWindow(hwnd, SW_SHOWNOACTIVATE);
}

//--------------------------------------------------------------------------
// Refresh our window contents
static void refresh_window(ea_t ea)
{
  qfree(text);                            // destroy the old string contents
  text = NULL;
  if ( isASCII(get_flags_novalue(ea)) )   // is an ascii string constant?
  {
    long stype = get_str_type(ea);        // string type
    if ( stype == ASCSTR_UNICODE          // is unicode string?...
      || stype == ASCSTR_ULEN2
      || stype == ASCSTR_ULEN4 )
    {
      int delta = 0;
      if ( stype == ASCSTR_ULEN2 )
        delta = 2;
      if ( stype == ASCSTR_ULEN4 )
        delta = 4;
      size_t size = get_item_size(ea);
      if ( size > delta )
      {
        size -= delta;
        text = (wchar_t *)qalloc(size+sizeof(wchar_t));
        if ( text != NULL )
        { // get string contents from the database
          get_many_bytes(ea+delta, text, size);
          text[size/2] = '\0';
          // if the window was not created, do it now
          if ( hwnd == NULL )
            create_window();
        }
      }
    }
  }
  if ( hwnd != NULL )              // our window exists only if a unicode string
  {                                // has been encountered
    SetWindowTextW(th, text);
//    RECT r;
//    GetClientRect(hwnd, &r);
//    InvalidateRect(hwnd, &r, true);
  }
  must_refresh = false;                   // we did refresh the window
}

//--------------------------------------------------------------------------
// We hook to IDP event to detect the database modifications
static int idaapi idp_callback(void *, int notification_code, va_list va)
{
  switch ( notification_code)
  {
    case processor_t::undefine:
    case processor_t::make_code:
    case processor_t::make_data:
      {
        ea_t ea = va_arg(va, ea_t);
        if ( displayed_ea == ea )  // the currently displayed address is being
          must_refresh = true;     // changed. it makes no sense to refresh
                                   // our window immediately since the changes
                                   // are not in the database yet. we just raise
                                   // a flag here and will check it in the ui
                                   // callback
      }
      break;
  }
  return 0;
}

//--------------------------------------------------------------------------
// We hook to user-interface events to detect the cursor movements
static int idaapi ui_callback(void *, int notification_code, va_list)
{
  switch ( notification_code )
  {
    case ui_refreshmarked:
      // the 'refreshmarked' event occurs very often - periodically when
      // ida is idle. we will use it to detect the cursor movements
      {
        ea_t ea = get_screen_ea(); // current cursor address
        if ( ea != displayed_ea || must_refresh )
        {
          displayed_ea = ea;
          refresh_window(ea);
        }
      }
      break;
    case ui_refresh:
      // when all disassembly listings are refreshed, we refresh our window too
      refresh_window(get_screen_ea());
      break;
  }

  return 0;
}

//--------------------------------------------------------------------------
void run(int)
{
  // do nothing since the plugin is not visible
}

//--------------------------------------------------------------------------
int init(void)
{
  // our plugin works only in the graphic version of IDA
  ida_window = (HWND)callui(ui_get_hwnd).vptr;
  if ( ida_window == NULL )
    return PLUGIN_SKIP;
  // Hook to IDA events
  hook_to_notification_point(HT_UI, ui_callback, NULL);
  hook_to_notification_point(HT_IDP, idp_callback, NULL);
  // Stay resident in the memory
  return PLUGIN_KEEP;
}

//--------------------------------------------------------------------------
void term(void)
{
  if ( hwnd != NULL )
    DestroyWindow(hwnd);
  unhook_from_notification_point(HT_UI, ui_callback);
  unhook_from_notification_point(HT_IDP, idp_callback);
}

//--------------------------------------------------------------------------
char help[] = "Unispector";
char comment[] = "Unispector";
char wanted_name[] = "Unispector";
char wanted_hotkey[] = "";


//--------------------------------------------------------------------------
//
//      PLUGIN DESCRIPTION BLOCK
//
//--------------------------------------------------------------------------
plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  PLUGIN_HIDE,          // plugin flags
  init,                 // initialize

  term,                 // terminate. this pointer may be NULL.

  run,                  // invoke plugin

  comment,              // long comment about the plugin
                        // it could appear in the status line
                        // or as a hint

  help,                 // multiline help about the plugin

  wanted_name,          // the preferred short name of the plugin
  wanted_hotkey         // the preferred hotkey to run the plugin
};
