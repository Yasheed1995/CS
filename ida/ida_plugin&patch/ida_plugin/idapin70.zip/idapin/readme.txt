
This is a PIN tool that is used to connect IDA Pro debugger and PIN.
IDA can use PIN to instrument a binary file, trace it, and even debug
it. Breakpoints can be added to the target process, it can be suspended and
the process state can be examined.

The PIN tool is shipped in the source form. You will need to compile it
for your operating system and PIN version.

Requirements:
  Windows: pin-81205, msvc-2015
  Linux: pin-81205, gcc 4.8.2 or higher

Copyright Hex-Rays 2014-2017
