if [ $__MAC__ ]; then
for py_i in QtCore QtGui QtXml QtDeclarative QtHelp QtMultimedia QtNetwork QtOpenGL QtScript QtScriptTools QtSql QtSvg QtTest QtUiTools QtXmlPatterns
do
(
echo "edit $py_i"
for qt_i in QtCore QtGui QtXml QtDeclarative QtHelp QtMultimedia QtNetwork QtOpenGL QtScript QtScriptTools QtSql QtSvg QtTest QtUiTools QtXmlPatterns
do
(
  echo   "-change" "/Users/Shared/Qt/4.8.1/lib/$qt_i.framework/Versions/4/$qt_i" "@executable_path/../Frameworks/$qt_i.framework/Versions/4/$qt_i" "/System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/site-packages/PySide/$py_i.so"

  install_name_tool -change "/Users/Shared/Qt/4.8.1/lib/$qt_i.framework/Versions/4/$qt_i" "@executable_path/../Frameworks/$qt_i.framework/Versions/4/$qt_i" "/System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/site-packages/PySide/$py_i.so"
)
done
)
done
fi