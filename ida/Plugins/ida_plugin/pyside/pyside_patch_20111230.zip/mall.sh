#! /bin/bash

#
# For windows build:
# make sure you have only one version of Python installed and that is the version
# that you want to build for.
# After the *.pyd are built, you need to copy shiboken-pythonXX.dll and pyside-pythonXX.dll as well
#

#set -o verbose
#set -v
#set -x

# This script builds PySide on Linux/Mac
# Usage:
#       ./mall clean            -- remove build results
#       ./mall                  -- build
#       ./mall install          -- install the result to /usr/local

set -e # stop on any error

# Make sure our QT namespace value is set
export QT_NAMESPACE=QT

cmake="cmake"
make="make"
install="sudo make install"

if [ $__MAC__ ]; then
  CMAKE_FLAGS="-DALTERNATIVE_QT_INCLUDE_DIR=/Users/Shared/Qt/4.8.1/include \
               -DQT_MAC_USE_COCOA=1"
elif [ $__LINUX__ ]
then
  export LD_LIBRARY_PATH=/usr/local/lib
else # Windows
  qcmake="/cygdrive/c/Program Files (x86)/CMake 2.8/bin/cmake.exe"
  if [ ! -f "$cmake" ]
  then
    qcmake="/cygdrive/c/cmake/bin/cmake.exe"
  fi

  OUTDIR=$(pwd)/bin
  if [ -d $OUTDIR ] ; then
    cd $OUTDIR
    rm -rf *
    cd ..
  else
    mkdir $OUTDIR
  fi

  CMAKE_FLAGS="-G \"NMake Makefiles\" -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$OUTDIR"
  make=nmake
  install="$make install"

  __WINDOWS__=1
fi

# Folders in question...
echo "Working directory is" $(pwd)
echo "Using Cmake @ $cmake"
for i in apiextractor generatorrunner shiboken pyside
do
  (
    cd $i/build
    if [ "$1" == "clean" ] ; then
      echo "Cleaning $i......."
      rm -rf *
    elif [ "$1" == "install" ] ; then
      eval $install
    else
      eval "$cmake" $CMAKE_FLAGS ..
      $make
      if [ $__WINDOWS__ ] ; then
        eval $install
      fi
    fi
  )
done

if [ $__MAC__ ]; then
for py_i in QtCore QtGui QtXml QtDeclarative QtHelp QtMultimedia QtNetwork QtOpenGL QtScript QtScriptTools QtSql QtSvg QtTest QtUiTools QtXmlPatterns
do
(
echo "edit $py_i"
for qt_i in QtCore QtGui QtXml QtDeclarative QtHelp QtMultimedia QtNetwork QtOpenGL QtScript QtScriptTools QtSql QtSvg QtTest QtUiTools QtXmlPatterns
do
(
  echo   "-change" "/Users/Shared/Qt/4.8.1/lib/$qt_i.framework/Versions/4/$qt_i" "@executable_path/../Frameworks/$qt_i.framework/Versions/4/$qt_i" "/System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/site-packages/PySide/$py_i.so"

  install_name_tool -change "/Users/Shared/Qt/4.8.1/lib/$qt_i.framework/Versions/4/$qt_i" "@executable_path/../Frameworks/$qt_i.framework/Versions/4/$qt_i" "/System/Library/Frameworks/Python.framework/Versions/2.6/lib/python2.6/site-packages/PySide/$py_i.so"
)
done
)
done
fi
