
How to build PySide
-------------------

1. Unarchive the following file to a directory of your choice:

pyside_clone.tgz		This file contains a copy of git repertoire
                                of PySide at 2011-03-28, as is.

2. "cd dload" and apply our patch: pyside_patch_20110328.zip

3. To build everything, just use ./mall
   Just to be on safe side, repeat ./mall

4. Install it using ./mall install
   The package gets installed to /usr/local/lib/python2.6/site-packages/PySide
   On Mac, this is wrong. I moved it to /usr/lib/python2.6/PySide


Ready-to-use prebuilt packages
------------------------------

I built PySide for Linux and Mac OS X, but did not work MS Windows:

mac_pyside_python26_package.tgz
linux_pyside_python26_package.tgz

The 'mall' batch file in theory should handle all 3 OSes but I did not test it
under MS Windows.

2012-03-28
Ilfak
