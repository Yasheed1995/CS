var searchData=
[
  ['xref_20options',['Xref options',['../group___s_w___x.html',1,'']]],
  ['xref_20enumeration_20flags',['Xref enumeration flags',['../group___x_r_e_f__.html',1,'']]]
];
