var searchData=
[
  ['ud',['ud',['../structdata__type__t.html#a8b886dfe21a87737ec0d16fcd8b667c9',1,'data_type_t::ud()'],['../structdata__format__t.html#aa3ab0a40a4a3bce97271fb46708b944d',1,'data_format_t::ud()']]],
  ['uflag',['uflag',['../structasm__t.html#a4e8ab72bbf5da7cf54ab7942155cddf3',1,'asm_t']]],
  ['undeclared_5fvariable_5fok',['undeclared_variable_ok',['../structidcfuncs__t.html#a58c33943de9c58b9c59e36fa54551385',1,'idcfuncs_t']]],
  ['under_5fdebugger',['under_debugger',['../pro_8h.html#a634763e97c3f75cfe9d667a6f434f3ad',1,'pro.h']]],
  ['unicode',['unicode',['../structtoken__t.html#a1b9282c58fa99531f1e7ae01eb98a9a8',1,'token_t']]],
  ['unload_5fprocmod',['unload_procmod',['../structextlang__t.html#af5df90638bac7f4ab1a45425a0186284',1,'extlang_t']]],
  ['unpadded_5fsize',['unpadded_size',['../structudt__type__data__t.html#af25f3afe30c6ae1c919a5b9e77848b88',1,'udt_type_data_t']]],
  ['unused_5fslot',['unused_slot',['../structprocessor__t.html#a62aee2fa2fba2d3a642f730ff0e0c3e8',1,'processor_t']]],
  ['update_5fbpts',['update_bpts',['../structdebugger__t.html#a5672d4377caebeb5022eba32e9f020fd',1,'debugger_t']]],
  ['update_5fcall_5fstack',['update_call_stack',['../structdebugger__t.html#a3d1c518900a2ec7dcb701b5f7498b164',1,'debugger_t']]],
  ['update_5flowcnds',['update_lowcnds',['../structdebugger__t.html#a487811d045a362c9d2352c7be182c0e5',1,'debugger_t']]],
  ['user',['user',['../structregvar__t.html#abf40e6a6ee836ebfcd729c362453153b',1,'regvar_t::user()'],['../structxrefblk__t.html#ab4d447ac9a7638a0dd7399aa4c3a58a8',1,'xrefblk_t::user()']]],
  ['userdata',['userdata',['../structioport__t.html#a52df8ef60f58083f47c52a3a0b23cfe7',1,'ioport_t']]]
];
