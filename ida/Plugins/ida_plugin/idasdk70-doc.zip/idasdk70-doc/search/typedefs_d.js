var searchData=
[
  ['optype_5ft',['optype_t',['../ua_8hpp.html#aaf9da6ae7e8b201108fc225adf13b4d9',1,'ua.hpp']]]
];
