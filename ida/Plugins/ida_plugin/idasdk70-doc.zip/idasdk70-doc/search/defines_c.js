var searchData=
[
  ['opaque_5fhandle',['OPAQUE_HANDLE',['../pro_8h.html#a883104093038da6648f4f4973d05641b',1,'pro.h']]],
  ['operator_5fnew',['OPERATOR_NEW',['../pro_8h.html#aef073c2546a5ff20623dcce4fe6edc74',1,'pro.h']]]
];
