var searchData=
[
  ['regval_5ftype_5ft',['regval_type_t',['../registry_8hpp.html#a68552d86f5bb5687eb2828179ac0a3a7',1,'registry.hpp']]],
  ['resume_5fmode_5ft',['resume_mode_t',['../idd_8hpp.html#a22acbc39891c15a300bd1ddf85edafae',1,'idd.hpp']]]
];
