var searchData=
[
  ['registry_2ehpp',['registry.hpp',['../registry_8hpp.html',1,'']]]
];
