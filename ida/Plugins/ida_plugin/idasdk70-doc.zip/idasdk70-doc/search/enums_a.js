var searchData=
[
  ['ofile_5ftype_5ft',['ofile_type_t',['../loader_8hpp.html#aedd09d8d4388efa808171434ac541d13',1,'loader.hpp']]]
];
