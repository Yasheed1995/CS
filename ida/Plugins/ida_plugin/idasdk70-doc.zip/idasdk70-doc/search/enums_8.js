var searchData=
[
  ['linput_5fclose_5fcode_5ft',['linput_close_code_t',['../compress_8hpp.html#aa4b9b015580aa8ac2beaf0afaf277b7b',1,'compress.hpp']]],
  ['linput_5ftype_5ft',['linput_type_t',['../diskio_8hpp.html#ae0d44a8d9c28b414b8bf478053527261',1,'diskio.hpp']]]
];
