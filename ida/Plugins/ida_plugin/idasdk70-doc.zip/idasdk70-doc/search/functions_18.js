var searchData=
[
  ['xrefchar',['xrefchar',['../group__xref__type.html#ga36716f163bdee48c9e94ff947deb7d65',1,'xref.hpp']]]
];
